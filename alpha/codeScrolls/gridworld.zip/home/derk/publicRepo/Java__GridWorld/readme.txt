# Author            : Derek Maier
# Date Created      : 17 Nov 2016
# Last Revision     : 20 Nov 2016
# Version           : 0.10

# ====================
#   Description
# ====================


# ====================
#   Notes
# ====================
# This project uses GSON to create JSON serialized objects for the user front end.

# ====================
#   Bugs
# ====================
