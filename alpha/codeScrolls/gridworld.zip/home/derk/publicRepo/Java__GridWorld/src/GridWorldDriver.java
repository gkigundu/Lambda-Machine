package gridworld;

import java.util.*;
// import java.io.*;
import java.awt.*;
import javax.swing.*;

import gridworld.Grid;

class GridWorldDriver{
	// ============================
	//    Main
	// ============================
	public static void main(String [ ] args){
		Random rand = new Random();
		long printTime = 3 ; // seconds between print
		boolean slowStep = true; // slows down the movement of the agent and algorithm execution
		// == Init Objects
		int mainLayout[][] = { // 20 x 20
			{ 0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0 },
			{ 0,  0, -1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, -1,  0 },
			{ 0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0 },
			{ 0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0 },
			{ 0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0 },
			{ 0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0 },
			{ 0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0 },
			{ 0,  0,  0,  0,  0,  0,  0,  0, -1, -1,  0,  0,  0,  0, -1,  0,  0,  0,  0,  0 },
			{ 0,  0,  0,  0, -1, -1,  0,  0, -1, -1,  0,  0,  0,  0,  0,  0,  0,  0, -1,  0 },
			{ 0,  0,  0,  0,  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, -1,  0 },
			{ 0,  0,  0,  0,  0, -1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, -1,  0 },
			{ 0,  0,  0,  0,  0, -1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0 },
			{ 0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0 },
			{ 0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0 },
			{ 0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0 },
			{ 0,  0,  0,  0,  0,  0,  0,  0,  0,  0, -1,  0,  0,  0,  0,  0,  0,  0,  0,  0 },
			{ 0,  0,  0,  0,  0,  0,  0,  0,  0,  0, -1,  0,  0,  0,  0,  0,  0,  0,  0,  0 },
			{ 0,  0,  0,  0,  0,  0,  0,  0,  0,  0, -1,  0,  0,  0,  0,  0,  0,  0, -1,  0 },
			{ 0,  0,  0,  0,  0, -1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, -1, -1,  0 },
			// { 0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0 },
		};
		// Random layout
		int size = 20;
		float chanceOfVoid = 0.05f;
		int randomeLayout[][] = new int[size][size];
		for (int i = 0 ; i < size ; i++ ){
			for (int j = 0 ; j < size ; j++ ){
				if( rand.nextFloat() < chanceOfVoid ){
					randomeLayout[i][j] = -1;
				}
				else{
					randomeLayout[i][j] = 0;
				}
			}
		}
		randomeLayout[rand.nextInt(size)][rand.nextInt(size)] = 1;
		// connect objects
		Grid aGrid = new Grid(randomeLayout);
		// Grid aGrid = new Grid(smallLayout);
		GridAgent agent1 = new GridAgent(aGrid);
		AgentPainter painter = new AgentPainter(agent1); // graphics
		// == SARSA
		logOut("Created agent on grid of size (H:" + aGrid.height + ", W:" + aGrid.width+")");
		boolean cont = true; // continue sarsa algorithm
		long secondsSinceEpoch = System.currentTimeMillis() / 1000l; // time for printout
		while(cont){
			agent1.reset(); // set agent to episode initial condition
			boolean rewardPunishment = false; // did the agent find a reward/punishment
			while( ! rewardPunishment){ // while he hasn't found a reward/punishment
				rewardPunishment = agent1.iterate(); // iterate and return if a reward/punishment found
				if(slowStep){
					try{Thread.sleep(200);		}
					catch(InterruptedException e){ }
				}
				painter.paintAgent(); // draw the agent
			}
			agent1.concludeEpisode();
			// console print
			if(( System.currentTimeMillis() / 1000l) -  secondsSinceEpoch > printTime){
				secondsSinceEpoch = System.currentTimeMillis() / 1000l;
				System.out.println("\033c" + agent1.toString()); // clears and print
				// System.out.println(agent1.toString()); // print
			}
		}
	}
	// ============================
	//    Helper Functions
	// ============================
	static void logOut(String str){
		System.out.println("<log> " + str);
	}
	static void logErr(String str){
		System.out.println("<ERROR> " + str);
	}
	static void FatalError(String str){
		System.out.println("<FATAL_ERROR> " + str);
		System.exit(1);
	}
}
