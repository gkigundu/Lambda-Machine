package gridworld;

import java.util.*;
// import com.google.gson.*;

// ============================
//    Grid Object
// ============================
class Grid{
	// == Attributes
	int width;
	int height;
	private int world[][];
	// == constructor
	public Grid(int grid[][] ) {
		this.height = grid.length;
		this.width = grid[0].length;

		// make sure it is a square matrix
		int curSize = grid[0].length;
		for (int i = 1 ; i < grid.length ; i ++){
			if (grid[i].length != curSize){
				throw new ArrayIndexOutOfBoundsException();
			}
		}
		this.world = grid;
	}
	public int rewardPunishment(int x, int y){
		return world[x][y];
	}
}
// ============================
//    Grid Agent Object
// ============================
class GridAgent{
	Random rand = new Random();
	static char arrows[] = {'^','>','v','<'};
	static int actions[] = {0, 1, 2, 3}; // 0 = top ; 1 = right ; 2 = down ; 3 = left
	// == Agent Long Term State Attributes
	float qTable[][][];
	float eTable[][][];
	Grid myGrid;
	// == SARSA Attributes
	float epsilon    = 0.9f; // Exploit v. explore // rand > epsilon == explot
	float epsilonMin = 0.1f; // Minimum percent of time to explore after epsilon decay
	float gama = 0.9f; // Discount factor(1 > x > .9)
	float lambda = 0.75f; // Decay rate on e table
	float alpha = 0.001f; // Learning rate
	float epsilonDecay = 0.0001f; // Decay after each episode ( explore ==> exploit )
	// == Agent Temporal State Attributes
	int curX;
	int curY;
	int projX;
	int projY;
	int action;
	// == Agent Metrics
	int   episode   = 0; // number of episodes that have transpired
	int   steps     = 0; // number of steps in this episode
	float avgSteps  = 0; // avg steps to goal across all episodes
	float successes = 0; // number of sucess
	float largestQValue  = 0; // largest value in qTable
	float smallestQValue = 0; // smallest value in qTable
	// == constructor
	public GridAgent(Grid myGrid) {
		int width = myGrid.width;
		int height = myGrid.height;
		this.qTable = new float[height][width][actions.length];
		this.eTable = new float[height][width][actions.length];
		this.myGrid = myGrid;
		this.genRandInitValues(10000);
	  this.eTableClear();
	}
	// == Methods
	boolean iterate(){
		int reward = projectAction(action);
		float delta = getDelta(reward, action);
		propegateDelta(delta);
		if(reward != 0){
			return true;
		}
		else{
			takeAction(action);
			action = getAction(curX, curY); // initial action
			return false;
		}
	}
	void concludeEpisode(){
		// == decay Epsilon
		if(epsilon - epsilon*epsilonDecay < epsilonMin){ // TODO : test this
			epsilon = epsilonMin;
		}
		else{
			epsilon -= epsilon * epsilonDecay;
		}
		// == collect avg step metrics
		avgSteps = (avgSteps * episode + steps) / (episode+1);
		episode++;	// next episode
		steps   = 0; // reset counter
	}
	void reset(){
		placeAtRandPoint(); // redrop agent at random spot
		eTableClear();
		action = getAction(curX, curY); // initial action
	}
	void placeAtPoint(int x, int y ){ // place agent at location
		this.curX = x;
		this.curY = y;
	}
	void placeAtRandPoint(){ // put agent at a random location
		placeAtPoint(
		rand.nextInt(myGrid.height),
		rand.nextInt(myGrid.width)
		);
	}
	void genRandInitValues(int devisionFactor){ // create random initial values in qTable divided by perameter 1
		smallestQValue = 0;
		largestQValue = 0;
		for(int i = 0 ; i < myGrid.height ; i++){
			for(int j = 0 ; j < myGrid.width ; j++){
				for(int k = 0 ; k < actions.length ; k++){
					qTable[i][j][k] = rand.nextFloat()/devisionFactor;
					if( qTable[i][j][k] > largestQValue){
						largestQValue = qTable[i][j][k] ;
					}
					else if( qTable[i][j][k] < smallestQValue){
						largestQValue = qTable[i][j][k] ;
					}
				}
			}
		}
	}
	float getDelta(int reward, int action){
		float projQ = 0;
		if(projX >= 0 && projY >= 0 && projX < myGrid.height && projY < myGrid.width){
			float max = qTable[projX][projY][0];
			for(int k = 1 ; k < actions.length ; k++){
				if(qTable[projX][projY][k] > max){
					max = qTable[projX][projY][k];
				}
			}
			projQ = max;
		}
		return reward + gama * (projQ - qTable[curX][curY][action]);
	}
	void propegateDelta(float delta){
		for(int i = 0 ; i < myGrid.height ; i++){
			for(int j = 0 ; j < myGrid.width ; j++){
				for(int k = 0 ; k < actions.length ; k++){
					if(eTable[i][j][k] != 0){
						qTable[i][j][k] += alpha * delta * eTable[i][j][k] ;
						eTable[i][j][k] = eTable[i][j][k] * lambda  * gama;
						if( qTable[i][j][k] > largestQValue){
							largestQValue = qTable[i][j][k] ;
						}
						else if( qTable[i][j][k] < smallestQValue){
							smallestQValue = qTable[i][j][k] ;
						}
					}
				}
			}
		}
	}
	void takeAction(int action){
		steps++; // count step
		if(action == 0){
			curX-=1;
		}
		else if(action == 1){
			curY+=1;
		}
		else if(action == 2){
			curX+=1;
		}
		else if(action == 3){
			curY-=1;
		}
		else{
			throw new IndexOutOfBoundsException("Index " + action + " is out of bounds!");
		}
	}
	int projectAction(int action){
		projX = curX;
		projY = curY;
		eTable[curX][curY][action] += 1;
		if(action == 0){
			projX-=1;
		}
		else if(action == 1){
			projY+=1;
		}
		else if(action == 2){
			projX+=1;
		}
		else if(action == 3){
			projY-=1;
		}
		else{
			throw new IndexOutOfBoundsException("Index " + action + " is out of bounds!");
		}
		if(projX >= 0 && projY >= 0 && projX < myGrid.height && projY < myGrid.width){
			int reward = myGrid.rewardPunishment(projX, projY);
			if(reward > 0){
				successes++;
			}
			return reward;
		}
		else{
			return -1;
		}
	}
	void eTableClear(){
		for(int i = 0 ; i < myGrid.height ; i++){
			for(int j = 0 ; j < myGrid.width ; j++){
				for(int k = 0 ; k < actions.length ; k++){
					eTable[i][j][k] = 0;
				}
			}
		}

	}
	int getAction(int x, int y){
		if(rand.nextFloat() > epsilon){
			float max = qTable[x][y][0];
			int bestAction = 0;
			for(int k = 1 ; k < actions.length ; k++){
				if(qTable[x][y][k] > max){
					max = qTable[x][y][k];
					bestAction = k;
				}
			}
			return bestAction;
		}
		else{
			return rand.nextInt(4);
		}

	}
	// == To String
	@Override
	public String toString() {
		String str = "";
		for(int x = 0 ; x < myGrid.height ; x++){
			for(int y = 0 ; y < myGrid.width ; y++){
				if(myGrid.rewardPunishment(x,y) > 0){
					str += " G";
				}
				else if(myGrid.rewardPunishment(x,y) < 0 ){
					str += " X";
				}
				else{
					float max = qTable[x][y][0];
					int bestAction = 0;
					for(int k = 1 ; k < actions.length ; k++){
						if(qTable[x][y][k] > max){
							max = qTable[x][y][k];
							bestAction = k;
						}
					}
					str += " " + arrows[bestAction];
				}
			}
			str += "\n";
		}
		str += "\n" ;
		str += "epsilon             : " + epsilon + "\n";
		str += "avg Steps / episode : " + avgSteps + "\n";
		str += "episode             : " + episode + "\n";
		str += "sucesses rate       : " + String.format("%.02f", (successes/episode)*100) + "%\n";
		str += "Largest Q Value     : " + largestQValue + "\n";
		str += "Smallest Q Value    : " + smallestQValue + "\n";
		str += "\n" ;
		return str;
	}
}
