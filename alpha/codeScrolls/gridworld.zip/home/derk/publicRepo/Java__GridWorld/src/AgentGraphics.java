package gridworld;

// import java.util.*;
// import java.io.*; // DELETE
import java.awt.*;
import javax.swing.*;

import gridworld.Grid;

// ============================
//    Graphics Object
// ============================
class AgentPainter{
	JFrame frame;
	GridAgent agent;
	public AgentPainter(GridAgent agent){
		this.agent = agent;
		frame = new JFrame("SARSA Lambda");
		frame.getContentPane();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(500, 500);
		frame.setVisible(true);
		frame.getContentPane().add(new Painter(agent));
	}
	void paintAgent(){
		frame.getContentPane().removeAll();
		frame.getContentPane().add(new Painter(agent));
		frame.revalidate();
	}
}
class Painter extends JPanel{
	GridAgent agent;
	public Painter(GridAgent agent){
		this.agent = agent;
	}
	protected void paintComponent(Graphics g){
		super.paintComponent(g);
		Graphics2D g2d = (Graphics2D) g.create();
		// == attributes
		int width = agent.myGrid.width;
		int height = agent.myGrid.height;
		int cellWidth = getSize().width / width;
		int cellHeight = getSize().height / height;
		float qDiff =  agent.largestQValue - agent.smallestQValue;
		// == each cell
		for(int i = 0 ; i < height ; i++){
			for(int j = 0 ; j < width ; j++){
				int cellTopLeft[] = {j*cellWidth, i*cellHeight};
				// == No reward at Cell
				if(agent.myGrid.rewardPunishment(i, j) == 0){
					// == Action Heat Map
					for(int k = 0 ; k < agent.actions.length ; k++){
						float actionValue = (agent.qTable[i][j][k] + Math.abs(agent.smallestQValue)) / qDiff;
						// System.out.println(agent.qTable[i][j][k]+"");

						try{ // Color selector heat map
							if(0 < actionValue && actionValue < 0.25){
								g2d.setColor(new Color(0.0f,actionValue,1.0f));
							}
							else if(actionValue < 0.50){
								g2d.setColor(new Color(0.0f,1.0f,(1-actionValue)));
							}
							else if(actionValue < 0.75){
								g2d.setColor(new Color(actionValue,1.0f,0.0f));
							}
							else if(actionValue <= 1){
								g2d.setColor(new Color(1.0f,(1-actionValue),0.0f));
							}
							else {
								System.out.println(agent.qTable[i][j][k] + " " + actionValue + " " + qDiff);
								g2d.setColor(Color.BLACK); // should not see this. This is a bug if so. black triangle == out of meat map color scope.
							}
						}
						catch (Throwable e){
							System.exit(1);
						}
						int xVal[] = {
							cellTopLeft[0],
							cellTopLeft[0]+cellWidth,
							cellTopLeft[0]+cellWidth/2
						}; // x values
						int yVal[] = {
							cellTopLeft[1],
							cellTopLeft[1],
							cellTopLeft[1]+cellHeight/2
						}; // x values
						if(k == 0){		}
						else if(k == 1){
							xVal[0] += cellWidth;
							yVal[0] += cellHeight;
						}
						else if(k == 2){
							yVal[0] += cellHeight;
							yVal[1] += cellHeight;
						}
						else if(k == 3){
							yVal[1] += cellHeight;
							xVal[1] -= cellWidth;
						}
						g2d.fillPolygon( xVal, yVal, 	3	);
						g2d.setColor(new Color(1.0f,1.0f,1.0f));
						// g2d.drawPolygon( xVal, yVal, 	3	);
					}
				}
				// == Punishment
				else if(agent.myGrid.rewardPunishment(i, j) < 0){
					g2d.setColor(Color.BLACK);
					g2d.fillOval(
					(j)*cellWidth,
					(i)*cellHeight,
					cellWidth,
					cellHeight
					);
				}
				// == Goal
				else if(agent.myGrid.rewardPunishment(i, j) > 0){
					g2d.setColor(new Color(255,215,0)); // GOLD
					g2d.fillOval(
					cellTopLeft[0],
					cellTopLeft[1],
					cellWidth,
					cellHeight
					);
				}
			}
		}
		// == Draw where the agent is
		g2d.setColor(Color.WHITE);
		g2d.fillOval(
		this.agent.curY*cellWidth   + (cellWidth/4),
		this.agent.curX*cellHeight  + (cellHeight/4)  ,
		cellWidth/2,
		cellHeight/2
		);
		// == grid horizontal lines
		g2d.setColor(Color.BLACK);
		for(int j = 0 ; j < width ; j++){
			g2d.drawLine(j * cellWidth, 0, j * cellWidth ,  getSize().height);
		}
		// == grid verticle lines
		g2d.setColor(Color.BLACK);
		for(int j = 0 ; j < height ; j++){
			g2d.drawLine(0, j * cellHeight, getSize().width, j * cellHeight );
		}
	}
}
